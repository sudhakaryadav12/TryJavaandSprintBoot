import pandas as pd

def load_cv_data(excel_path):
    return pd.read_excel(excel_path, dtype=str)
