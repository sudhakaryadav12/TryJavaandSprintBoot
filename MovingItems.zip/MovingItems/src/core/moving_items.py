import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../..")))

import pandas as pd
import numpy as np
import ast

from src.consumers.kafka_event_loader import load_event_data
from src.utils.data_loader import load_cv_data

def extract_coordinates_from_excel(cv_excel_df, unknown_items):
    matched_rows = []
    matched_coords = []
    coord_map = {}
    for item in unknown_items:
        sng_did = item.get("sng_did")
        global_id = item.get("global_id")
        person_event_time = item.get("person_event_time")
        filtered = cv_excel_df[
            (cv_excel_df["sng_did"] == sng_did) & (cv_excel_df["global_id"] == global_id)
        ]
        for _, row in filtered.iterrows():
            matched_rows.append(row.to_dict())
            coords_raw = row.get("timestamp_coordinates")
            if not coords_raw or not coords_raw.strip().startswith("[") or not coords_raw.strip().endswith("]"):
                continue
            try:
                parsed_coords = ast.literal_eval(coords_raw)
                if not isinstance(parsed_coords, list):
                    continue
                valid_coords = [
                    coord for coord in parsed_coords
                    if isinstance(coord, (list, tuple)) and len(coord) == 3
                ]
                for coord in valid_coords:
                    timevalue, x, y = coord
                    if timevalue == person_event_time:
                        try:
                            x = int(float(x))
                            y = int(float(y))
                            rfx =  x
                            rfy = 4960 - y
                            matched_coords.append({"x": x, "y": y})
                            if global_id not in coord_map:
                                coord_map[global_id] = []
                            coord_map[global_id].append({
                                "person_event_time": person_event_time,
                                "x": x,
                                "y": y,
                                "rfx": rfx,
                                "rfy": rfy
                            })
                        except Exception:
                            continue
            except (SyntaxError, ValueError):
                continue
    return matched_rows, matched_coords, coord_map

def get_rfx_rfy_list(coord_map, global_id):
    return [{"rfx": entry["rfx"], "rfy": entry["rfy"]}
            for entry in coord_map.get(global_id, [])]

def filter_and_clean_item_data(df):
    df = df[~df["events"].isin(["Departure", "Exit"])]
    df = df[df["regionName"].str.contains("apparel pad", case=False, na=False)]
    df["x"] = pd.to_numeric(df["x"], errors='coerce')
    df["y"] = pd.to_numeric(df["y"], errors='coerce')
    df = df.dropna(subset=["x", "y"])
    return df

def filter_by_coordinate_proximity(df, rfx_rfy_list, tolerance=50):
    rfx_array = np.array([point['rfx'] for point in rfx_rfy_list])
    rfy_array = np.array([point['rfy'] for point in rfx_rfy_list])
    def is_near(row):
        distance = np.sqrt((rfx_array-row["x"])**2+(rfy_array-row["y"])**2)
        return np.any(distance <= tolerance)
    return df[df.apply(is_near, axis=1)]

def main():
    kafkatopicjson_file = "data/kafkatopicdata.json"
    cvdata_file = "data/CVdata22.xlsx"
    itemcoreserver_file = "data/item_data_01.csv"
    unknown_kafka_event_json = load_event_data(kafkatopicjson_file)
    cvdata_df = load_cv_data(cvdata_file)

    unknown_items = [item for item in unknown_kafka_event_json if item.get("Item_type") == "unknown"]

    all_matched_rows = []
    all_matched_coords = []
    global_id_coord_map = {}

    batch_size = 5
    for i in range(0, len(unknown_items), batch_size):
        batch = unknown_items[i:i + batch_size]
        print(f"\nProcessing unknown kafka events batch {i // batch_size + 1}: Items {i} to {i + len(batch) - 1}")
        print("  Global IDs in this batch:")
        for item in batch:
            print(f"    - global_id: {item.get('global_id')}")
        matched_rows, matched_coords, coord_map = extract_coordinates_from_excel(cvdata_df, batch)
        all_matched_rows.extend(matched_rows)
        all_matched_coords.extend(matched_coords)
        for gid, coords in coord_map.items():
            if gid not in global_id_coord_map:
                global_id_coord_map[gid] = []
            global_id_coord_map[gid].extend(coords)

    print("\nFinal Dictionary (global_id -> list of {person_event_time, x, y, rfx, rfy}):")
    for gid, coords in global_id_coord_map.items():
        print(f"{gid}:")
        for c in coords:
            print(f"  {c}")

    rfx_rfy_list = []
    for gid in global_id_coord_map:
        rfx_rfy_list.extend(get_rfx_rfy_list(global_id_coord_map, gid))

    print("\nCombined RFX/RFY list for all global_ids:")
    print(rfx_rfy_list)

    chunksize = 10000
    chunk_number = 0
    matching_rows_accumulator = []

    for chunk in pd.read_csv(itemcoreserver_file, chunksize=chunksize):
        chunk_number += 1
        print(f"\nProcessing item data chunk {chunk_number}")
        filtered_chunk = filter_and_clean_item_data(chunk)
        matching_chunk = filter_by_coordinate_proximity(filtered_chunk, rfx_rfy_list)
        if not matching_chunk.empty:
            print(f"  ➤ Matching rows found in chunk {chunk_number}:")
            print(matching_chunk)
            matching_rows_accumulator.append(matching_chunk)
        else:
            print(f"  ➤ No matches found in chunk {chunk_number}")

    final_matching_rows = pd.concat(matching_rows_accumulator, ignore_index=True)
    print("\nFiltered Moving Item Data:")
    print(final_matching_rows)

if __name__ == "__main__":
    main()
