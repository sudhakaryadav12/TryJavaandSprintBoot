package com.brodygaudel.demo.config;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MoveITConfig {

    @Value("${moveit.api.url}")
    private String apiUrl;

    @Value("${moveit.api.token}")
    private String apiToken;

    public String getApiUrl() {
        return apiUrl;
    }

    public String getApiToken() {
        return apiToken;
    }
}