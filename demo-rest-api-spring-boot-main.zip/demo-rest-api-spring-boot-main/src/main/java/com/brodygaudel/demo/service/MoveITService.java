package com.brodygaudel.demo.service;


import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.brodygaudel.demo.config.MoveITConfig;

import java.util.HashMap;
import java.util.Map;

@Service
public class MoveITService {

    private final RestTemplate restTemplate;
    private final MoveITConfig moveITConfig;

    public MoveITService(MoveITConfig moveITConfig) {
        this.restTemplate = new RestTemplate();
        this.moveITConfig = moveITConfig;
    }

    public String createFolder(String folderName) {
        String url = moveITConfig.getApiUrl();
        
        // Construct JSON request body
        Map<String, String> requestBody = new HashMap<>();
        requestBody.put("parentId", "root");  // Change if needed
        requestBody.put("name", folderName);

        // Set headers
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("Authorization", "Bearer " + moveITConfig.getApiToken());

        HttpEntity<Map<String, String>> request = new HttpEntity<>(requestBody, headers);

        try {
            ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.POST, request, String.class);
            if (response.getStatusCode() == HttpStatus.CREATED || response.getStatusCode() == HttpStatus.OK) {
                return "Folder created successfully: " + folderName;
            }
            return "Failed to create folder. Response: " + response.getBody();
        } catch (Exception e) {
            return "Error creating folder: " + e.getMessage();
        }
    }
}
