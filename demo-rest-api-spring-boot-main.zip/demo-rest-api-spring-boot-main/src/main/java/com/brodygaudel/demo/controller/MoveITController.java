package com.brodygaudel.demo.controller;



import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.brodygaudel.demo.service.MoveITService;

@RestController
@RequestMapping("/mft")
public class MoveITController {

    private final MoveITService moveITService;

    public MoveITController(MoveITService moveITService) {
        this.moveITService = moveITService;
    }

    @PostMapping("/createFolder")
    public ResponseEntity<String> createFolder(@RequestParam String folderName) {
        String result = moveITService.createFolder(folderName);
        return ResponseEntity.ok(result);
    }
}
