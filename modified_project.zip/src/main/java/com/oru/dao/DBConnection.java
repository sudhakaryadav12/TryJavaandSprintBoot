package com.oru.dao;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
 
public class DBConnection {


     
    public static Connection getConnectionToPG() {
        //FileInputStream fis = null;
        InputStream fis = null;
        Connection con = null;
        InputStream dbfis = null;
        try {
            Properties props = new Properties();
            //fis = new FileInputStream( "/home/oru/NMSFileExtract/database.properties");
          //  fis = new FileInputStream( "database.properties");
           fis =  DBConnection.class.getClassLoader().getResourceAsStream("applicationconfig.properties");
            //System.out.println("Path2: "+ ClassLoader.getSystemClassLoader().getClass().getResource("/resources/database.properties").getPath());
            
            
            //fis = ClassLoader.getSystemClassLoader().getClass().getResourceAsStream("/resources/database.properties");
            //fis = ClassLoader.getSystemClassLoader().getClass().getResourceAsStream("/resources/database.properties");
    		props.load( fis );
    		fis.close();
    		String configFilePath = props.getProperty("NMSModelExtractConfig");
    		Properties dbprops = new Properties();
    		dbfis = new FileInputStream(configFilePath);
    		dbprops.load( dbfis );
    		dbfis.close();
            Class.forName(dbprops.getProperty("PG_DRIVER_CLASS"));
            con = DriverManager.getConnection(dbprops.getProperty("PG_URL"),
            		dbprops.getProperty("PG_USERNAME"),
            		dbprops.getProperty("PG_PASSWORD"));
            //System.out.println("Got Connection");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return con;
    }
    
       
    private static final String buildFullPath(String fileName) {
		return System.getProperty( "user.dir" ) + File.separator + fileName;
	}    
  }