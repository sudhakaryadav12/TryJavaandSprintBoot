/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.oru.modelExtract;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author talatis
 */
public class EntryPoint {

    private final static Logger logger = LoggerFactory.getLogger(EntryPoint.class);

    public static void main(String args[]) {
        //new EntryPoint(120);
        
        
        
        logger.info("Program starting please wait....");
        
        ExtractFeederInformation feederInfo = new ExtractFeederInformation();
        feederInfo.extractAllFeeder();

        logger.info("Exiting..");
    }

}
