/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.oru.modelExtract;

import com.oru.dao.DBConnection;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author TALATIS
 */
public class DistGenAttributesThread extends Thread  {
    
    HashMap<Integer, Asset> assetMaster;
    String assetToQuery;
    
    private final static Logger logger = LoggerFactory.getLogger(DistGenAttributesThread.class);
    

    DistGenAttributesThread(HashMap<Integer, Asset> assetMaster,String assetToQuery) {
        this.assetMaster = assetMaster;        
        this.assetToQuery = assetToQuery;
    }
    
    
    
    
        public void run() {

        //logger.info("Thread starting");
        try (Connection con = DBConnection.getConnectionToPG();
                Statement connectionGeomStmt = con.createStatement();) {


            
            String newPointQuery = "select geom.fid,geom.featuretypeid,def.featuretypename,\n" +
"                    GeometryType(geom.geom) geomType,geom.rotation,ST_X(geom) xValue,\n" +
"                    ST_Y(geom) yValue, dg.hgridx, dg.hgridy, dg.type, dg.kwcap, dg.volt,dg.premisenumb, dg.circuit, \n" +
"		     dg.phase, dg.fid1, dg.fid2, dg.mainline, dg.seg,dg.subseg,dg.hrcontact,dg.inservicedate,dg.customertype \n" +
"                    from ed.geom geom, nrgcore.nrgfeaturetypedef def, asset_ed.distributed_generation dg\n" +
"                    where geom.featuretypeid = def.featuretypeid\n" +
"                    and dg.fid = geom.fid  \n" +
"                    and dg.fid in (" + assetToQuery + ") \n" +                    
"                    order by fid ";

            //####logger.info(connectionGeomQuery);
            ResultSet rs = connectionGeomStmt.executeQuery(newPointQuery);
            
            while (rs.next()) {
                int fid = rs.getInt("fid");
                Asset asset = assetMaster.get(fid);

                if (asset != null) {

                    //asset.setCircuit(circuit);
                    asset.setNmsAttributes("fid", String.valueOf(fid));

                    int ftypeid = rs.getInt("featuretypeid");
                    asset.setNmsAttributes("featuretypeid", String.valueOf(ftypeid));

                    String featuretypename = rs.getString("featuretypename");
                    asset.setNmsAttributes("featuretypename", featuretypename);
                    asset.setAssetType(featuretypename);

                    String geomType = rs.getString("geomType");
                    asset.setNmsGeomAttributes("geomType", geomType);
                    asset.setGeomType(geomType);
                    
                    double rotation = rs.getFloat("rotation");
                    asset.setNmsGeomAttributes("rotation", String.valueOf(rotation));
                    
                    double pointX = rs.getFloat("xValue");
                    double pointY = rs.getFloat("yValue");
                    String geometry = "(" + String.valueOf(pointX) + "," + String.valueOf(pointY) + ")";
                    asset.setNmsGeomAttributes("geometry", geometry);

                    int gridx = rs.getInt("hgridx");
                    asset.setNmsAttributes("hgridx", Integer.toString(gridx));

                    int gridy = rs.getInt("hgridy");
                    asset.setNmsAttributes("hgridy", Integer.toString(gridy));

                    String type = rs.getString("type");
                    asset.setNmsAttributes("type", type);

                    double kwcap = rs.getFloat("kwcap");
                    asset.setNmsAttributes("kwcap", String.format("%.2f",kwcap));
                    
                    double volt = rs.getFloat("volt");
                    //asset.setNmsAttributes("volt", String.valueOf(volt));
                    asset.setNmsAttributes("volt", String.format("%.2f", volt));  
                    
                    
                    String premisenumb = rs.getString("premisenumb");
                    asset.setNmsAttributes("premisenumb", premisenumb);
                    
                    String circuit = rs.getString("circuit");
                    if (circuit.equalsIgnoreCase("L100-00/00-34")) {
                          circuit = "L6-00/00-34";
                    }                    
                    asset.setCircuit(circuit);
                    asset.setNmsAttributes("circuit", circuit);

                    int phase = rs.getInt("phase");
                    asset.setNmsAttributes("phase", Integer.toString(phase));

                    long fid1 = rs.getLong("fid1");
                    asset.setNmsAttributes("fid1", Long.toString(fid1));
                    
                    long fid2 = rs.getLong("fid2");
                    asset.setNmsAttributes("fid2", Long.toString(fid2));

                    String mainline = rs.getString("mainline");
                    asset.setNmsAttributes("mainline", mainline);

                    String seg = rs.getString("seg");
                    asset.setNmsAttributes("seg", seg);

                    String subseg = rs.getString("subseg");
                    asset.setNmsAttributes("subseg", subseg);

                    String hrcontact = rs.getString("hrcontact");
                    asset.setNmsAttributes("hrcontact", hrcontact);

                    String customertype = rs.getString("customertype");
                    asset.setNmsAttributes("customertype", customertype);
                    
                    Timestamp inservicedate = rs.getTimestamp("inservicedate");
                    if(inservicedate != null)
                    {
                        String inservicedateStr = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss").format(inservicedate);
                        asset.setNmsAttributes("inservicedate", inservicedateStr);
                    }
                    else
                    {
                        asset.setNmsAttributes("inservicedate", "");
                    }
                    
                    
                
                }

            }
            rs.close();
            //####logger.info("Thread finished processing");
        } catch (Exception e) {
            logger.error(e.getMessage());
        }

    }

}
