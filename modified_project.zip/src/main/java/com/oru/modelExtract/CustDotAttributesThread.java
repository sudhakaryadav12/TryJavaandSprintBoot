/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.oru.modelExtract;

import com.oru.dao.DBConnection;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author talatis
 */
public class CustDotAttributesThread extends Thread {

    HashMap<Integer, Asset> assetMaster;
    String assetToQuery;
    String circuit;
    
    private final static Logger logger = LoggerFactory.getLogger(CustDotAttributesThread.class);
    
    
    
    CustDotAttributesThread(HashMap<Integer, Asset> assetMaster,String assetToQuery,String circuit) {
        this.assetMaster = assetMaster;
        this.assetToQuery = assetToQuery;
        if (circuit.equalsIgnoreCase("L100-00/00-34")) {
            circuit = "L6-00/00-34";
        }
        this.circuit = circuit;
    }

    public void run() {

        //logger.info("Thread starting");
        try (Connection con = DBConnection.getConnectionToPG();
                Statement connectionGeomStmt = con.createStatement();) {

            String connectionGeomQuery = "select geom.fid,geom.featuretypeid,def.featuretypename,     \n" +
"                     geom.attributes,GeometryType(geom.geom) geomType,geom.rotation,ST_X(geom) xValue,     \n" +
"                     ST_Y(geom) yValue , cims.fulladdress,custdot.trangridx, custdot.trangridy,custdot.servpolex,custdot.tax,custdot.servpoley,     \n" +
"                     custdot.servorder1, custdot.servorder2,custdot.servorder3,custdot.servorder4,concat(cims.ad_serv_str_no , ' ',cims.ad_serv_str_nm , ' ' , cims.ad_serv_str_sfix , ' ' , cims.ad_serv_struc) as street , cims.ad_serv_city as city , cims.ad_serv_st as state    \n" +
"                     from ed.geom geom, nrgcore.nrgfeaturetypedef def, ed.connection conn, asset_ed.ed_custdot custdot , mainframe.cims_acct_active cims , ed.premise nrg\n" +
"                     where geom.featuretypeid = def.featuretypeid     \n" +
"                     and geom.fid = conn.fida     \n" +
"                     and custdot.fid = geom.fid     \n" +
"                     and nrg.fid = geom.fid     \n" +
"                     and cims.ky_prem_no = nrg.account \n" +
"                    and custdot.fid in (" + assetToQuery + ")";                     

            //####logger.info(connectionGeomQuery);
            try (ResultSet rs = connectionGeomStmt.executeQuery(connectionGeomQuery)) {
                while (rs.next()) {
                    int fid = rs.getInt("fid");
                    Asset asset = assetMaster.get(fid);
                    if (asset != null) {

                        asset.setNmsAttributes("fid", String.valueOf(fid));

                        int ftypeid = rs.getInt("featuretypeid");
                        asset.setNmsAttributes("featuretypeid", String.valueOf(ftypeid));

                        String featuretypename = rs.getString("featuretypename");
                        asset.setNmsAttributes("featuretypename", featuretypename);
                        asset.setAssetType(featuretypename);

                        String attributes = rs.getString("attributes");
                        for (String retval : attributes.split("::")) {
                            String val[] = retval.split(":");
                            asset.setNmsAttributes(val[0], val[1]);
                        }

                        String geomType = rs.getString("geomType");
                        asset.setNmsGeomAttributes("geomType", geomType);
                        asset.setGeomType(geomType);

                        double rotation = rs.getFloat("rotation");
                        asset.setNmsGeomAttributes("rotation", String.valueOf(rotation));

                        double pointX = rs.getFloat("xValue");
                        double pointY = rs.getFloat("yValue");
                        String geometry = "(" + String.valueOf(pointX) + "," + String.valueOf(pointY) + ")";
                        asset.setNmsGeomAttributes("geometry", geometry);
                        
                        String fulladdress = rs.getString("fulladdress");
                        asset.setNmsAttributes("fulladdress", fulladdress);
                        
                        int trangridx = rs.getInt("trangridx");
                        asset.setNmsAttributes("trangridx", String.valueOf(trangridx));
                        
                        int trangridy = rs.getInt("trangridy");
                        asset.setNmsAttributes("trangridy", String.valueOf(trangridy));
                        
                        int servpolex = rs.getInt("servpolex");
                        asset.setNmsAttributes("servpolex", String.valueOf(servpolex));
                        
                        int servpoley = rs.getInt("servpoley");
                        asset.setNmsAttributes("servpoley", String.valueOf(servpoley));                       
                        
                        String tax = rs.getString("tax");
                        asset.setNmsAttributes("tax", tax);
                        
                        String servorder1 = rs.getString("servorder1");
                        asset.setNmsAttributes("servorder1", servorder1);
                        String servorder2 = rs.getString("servorder2");
                        asset.setNmsAttributes("servorder2", servorder2);
                        String servorder3 = rs.getString("servorder3");
                        asset.setNmsAttributes("servorder3", servorder3);
                        String servorder4 = rs.getString("servorder4");
                        asset.setNmsAttributes("servorder4", servorder4);
                        String street = rs.getString("street");
                        asset.setNmsAttributes("street", street);
                        asset.setNmsAttributes("location", street);

                        String town = rs.getString("city");
                        asset.setNmsAttributes("town", town);

                        String state = rs.getString("state");
                        asset.setNmsAttributes("state", state);
                        
                        
                        if(asset.nmsAttributes.containsKey("circuit") == false)
                        {
                            asset.setNmsAttributes("circuit", circuit);
                        }
                        

                    }

                }
            }
            //####logger.info("Thread finished processing");

        } catch (Exception e) {
            logger.error(e.getMessage());
        }

    }
}
