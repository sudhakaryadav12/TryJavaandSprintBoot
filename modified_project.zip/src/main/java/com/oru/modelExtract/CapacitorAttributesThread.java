/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.oru.modelExtract;

import com.oru.dao.DBConnection;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author TALATIS
 */
public class CapacitorAttributesThread extends Thread  {
    
    HashMap<Integer, Asset> assetMaster;
    String assetToQuery;
    
    private final static Logger logger = LoggerFactory.getLogger(CapacitorAttributesThread.class);

    CapacitorAttributesThread(HashMap<Integer, Asset> assetMaster,String assetToQuery) {
        this.assetMaster = assetMaster; 
        this.assetToQuery = assetToQuery;
    }
    
    
    
    
        public void run() {

        //logger.info("Thread starting");
        try (Connection con = DBConnection.getConnectionToPG();
                Statement connectionGeomStmt = con.createStatement();) {


            
            String newPointQuery = "select distinct geom.fid,geom.featuretypeid,def.featuretypename,GeometryType(geom.geom) geomType,\n" +
                                "geom.rotation,ST_X(geom) xValue, ST_Y(geom) yValue,r.*\n" +
                                "FROM ed.geom geom, nrgcore.nrgfeaturetypedef def,asset_ed.capacitor r, ed.connection conn\n" +
                                "where geom.fid = r.fid \n" +
                                "and geom.fid = conn.fida\n" +
                                "and r.fid = conn.fida \n" +
                                "and geom.featuretypeid = def.featuretypeid\n" +
                                "and r.fid in (" + assetToQuery + ") \n" +                    
                                "order by geom.fid";

            //####logger.info(connectionGeomQuery);
            ResultSet rs = connectionGeomStmt.executeQuery(newPointQuery);
            
            while (rs.next()) {
                int fid = rs.getInt("fid");
                Asset asset = assetMaster.get(fid);

                if (asset != null) {

                    //asset.setCircuit(circuit);
                    asset.setNmsAttributes("fid", String.valueOf(fid));

                    int ftypeid = rs.getInt("featuretypeid");
                    asset.setNmsAttributes("featuretypeid", String.valueOf(ftypeid));

                    String featuretypename = rs.getString("featuretypename");
                    asset.setNmsAttributes("featuretypename", featuretypename);
                    asset.setAssetType(featuretypename);

                    String geomType = rs.getString("geomType");
                    asset.setNmsGeomAttributes("geomType", geomType);
                    asset.setGeomType(geomType);
                    
                    double rotation = rs.getFloat("rotation");
                    asset.setNmsGeomAttributes("rotation", String.valueOf(rotation));

                    double pointX = rs.getFloat("xValue");
                    double pointY = rs.getFloat("yValue");
                    String geometry = "(" + String.valueOf(pointX) + "," + String.valueOf(pointY) + ")";
                    asset.setNmsGeomAttributes("geometry", geometry);

                    String circuit = rs.getString("circuit");
                    if (circuit.equalsIgnoreCase("L100-00/00-34")) {
                          circuit = "L6-00/00-34";
                    }                    
                    asset.setCircuit(circuit);
                    asset.setNmsAttributes("circuit", circuit);
                                        
                    boolean sotagged = rs.getBoolean("sotagged");
                    asset.setNmsAttributes("sotagged", String.valueOf(sotagged));
                    
                    int gridx = rs.getInt("gridx");
                    asset.setNmsAttributes("gridx", Integer.toString(gridx));

                    int gridy = rs.getInt("gridy");
                    asset.setNmsAttributes("gridy", Integer.toString(gridy));

                    String division = rs.getString("division");
                    asset.setNmsAttributes("division", division);
                    
                    String seg = rs.getString("seg");
                    asset.setNmsAttributes("seg", seg);  
                    
                    String location = rs.getString("location");
                    asset.setNmsAttributes("location", location);
                    
                    int banksize = rs.getInt("banksize");
                    asset.setNmsAttributes("banksize", Integer.toString(banksize));
                    
                    String fixedorswitched = rs.getString("fixedorswitched");
                    asset.setNmsAttributes("fixedorswitched", fixedorswitched);                    
                    
                    int caponvoltage = rs.getInt("caponvoltage");
                    asset.setNmsAttributes("caponvoltage", Integer.toString(caponvoltage));
                    
                    int capoffvoltage = rs.getInt("capoffvoltage");
                    asset.setNmsAttributes("capoffvoltage", Integer.toString(capoffvoltage));
                    
                    int timedelay = rs.getInt("timedelay");
                    asset.setNmsAttributes("timedelay", Integer.toString(timedelay));
                    
                    int bias = rs.getInt("bias");
                    asset.setNmsAttributes("bias", Integer.toString(bias));                    
                    
                    int rating = rs.getInt("rating");
                    asset.setNmsAttributes("rating", Integer.toString(rating));    
                    
                    int sizeofcans = rs.getInt("sizeofcans");
                    asset.setNmsAttributes("sizeofcans", Integer.toString(sizeofcans));    
                    
                    int numofcans = rs.getInt("numofcans");
                    asset.setNmsAttributes("numofcans", Integer.toString(numofcans));    
                    
                    int numberofphases = rs.getInt("numberofphases");
                    asset.setNmsAttributes("numberofphases", Integer.toString(numberofphases));    
                    
                    String ptsensingphase = rs.getString("ptsensingphase");
                    asset.setNmsAttributes("ptsensingphase", ptsensingphase);    
                    
                    String manufacturer = rs.getString("manufacturer");
                    asset.setNmsAttributes("manufacturer", manufacturer);    
                    
                    String ckttieflag = rs.getString("ckttieflag");
                    asset.setNmsAttributes("ckttieflag", ckttieflag);
                    
                    String notes = rs.getString("notes");
                    asset.setNmsAttributes("notes", notes);
                    
                    int phase = rs.getInt("phase");
                    asset.setNmsAttributes("phase", Integer.toString(phase));    
                    
                    int wafid1 = rs.getInt("wafid1");
                    asset.setNmsAttributes("wafid1", Integer.toString(wafid1));    

                    int wafid2 = rs.getInt("wafid2");
                    asset.setNmsAttributes("wafid2", Integer.toString(wafid2));    
                    
                    String designdstat = rs.getString("designdstat");
                    asset.setNmsAttributes("designdstat", designdstat);
                    
                    String dstat = rs.getString("dstat");
                    asset.setNmsAttributes("dstat", dstat);

                    String subseg = rs.getString("subseg");
                    asset.setNmsAttributes("subseg", subseg);
                    
                    String scada = rs.getString("scada");
                    asset.setNmsAttributes("scada", scada);
                    
                    Timestamp dateinstalled = rs.getTimestamp("dateinstalled");
                    if(dateinstalled != null)
                    {
                        String dateinstalledStr = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss").format(dateinstalled);
                        asset.setNmsAttributes("dateinstalled", dateinstalledStr);
                    }
                    else
                    {
                        asset.setNmsAttributes("dateinstalled", "");
                    }
                    
                    Timestamp datecommissioned = rs.getTimestamp("datecommissioned");
                    if(datecommissioned != null)
                    {
                        String datecommissionedStr = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss").format(datecommissioned);
                        asset.setNmsAttributes("datecommissioned", datecommissionedStr);
                    }
                    else
                    {
                        asset.setNmsAttributes("datecommissioned", "");
                    }
                    
                    String wmsnumber_install = rs.getString("wmsnumber_install");
                    asset.setNmsAttributes("wmsnumber_install", wmsnumber_install);

                    String wmsnumber_commission = rs.getString("wmsnumber_commission");
                    asset.setNmsAttributes("wmsnumber_commission", wmsnumber_commission);
                    
                    String mainline = rs.getString("mainline");
                    asset.setNmsAttributes("mainline", mainline);

                    
                }

            }
            rs.close();
            //####logger.info("Thread finished processing");
        } catch (Exception e) {
            logger.error(e.getMessage());
        }

    }

}









  


