package com.oru.modelExtract;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class FileWriter {
	//private static final Logger logger = LoggerFactory.getLogger(FileWriter.class);
	Path file;
	BufferedWriter writer;
        
        private final static Logger logger = LoggerFactory.getLogger(FileWriter.class);
	
	public void create(String fileName) throws FileException{	
		try {
		file = Paths.get(fileName);
		Boolean isExist = Files.exists(file);
    	logger.info("File Exists[" + isExist+"]");    	
    	//Files.deleteIfExists(file);
	    	if(!isExist){
				file = Files.createFile(file);
				//logger.info("Created File["+ fileName+"]");
	    	}
	    	writer = Files.newBufferedWriter(file, Charset.forName("UTF-8"));
		} catch (Exception e) {
			//e.printStackTrace();
			throw new FileException("Error creating file;" + e.getMessage());
		}   
    
		//file = Paths.get(fileName);		
		/*try {*/
		    // Create the empty file with default permissions, etc.
		    //file = Files.createFile(file);
		/*} catch (FileAlreadyExistsException x) {
		    System.err.format("file named %s" +
		        " already exists%n", file);
		} catch (IOException x) {
		    // Some other sort of failure, such as permissions.
		    System.err.format("createFile error: %s%n", x);
		}*/

	}
	
	public void close() throws FileException{
		try {
			writer.close();
                        writer = null;
                        file = null;
		} catch (Exception e) {		
			throw new FileException("Error closing the file; " + e.getMessage());
		}
	}
	
	public void writeToNewLine(String st) throws FileException{
		//BufferedWriter writer = Files.newBufferedWriter(file, Charset.defaultCharset());
	//	BufferedWriter writer = Files.newBufferedWriter(file, Charset.forName("UTF-8"));		
		try {
			writer.newLine();
			writer.append(st);
			writer.flush();	 
		} catch (Exception e) {			
			throw new FileException("Error writing toFile; " + e.getMessage());
		}	    	    
	       
	}
	
	public void write(String line) throws FileException{
		//BufferedWriter writer = Files.newBufferedWriter(file, Charset.forName("UTF-8"));
		try {
			//logger.info(writer);
			writer.append(line);
			writer.flush();	
		} catch (Exception e) {		
			throw new FileException(e);
		}	    	    
	}
	
	/*public void write(List<String> lines) throws IOException{		
		Files.write(file, lines, Charset.forName("UTF-8"),StandardOpenOption.CREATE, StandardOpenOption.APPEND);
		//Files.write(file, line.getBytes(), StandardOpenOption.CREATE, StandardOpenOption.APPEND);
		//Files.write(file, lines, Charset.forName("UTF-8"), StandardOpenOption.APPEND);		
	}*/
	
	public void read() throws FileException {
		try(BufferedReader reader = Files.newBufferedReader(
				file, Charset.defaultCharset())){
	      String lineFromFile = "";
	      //logger.info("The contents of file are: ");
	      while((lineFromFile = reader.readLine()) != null){
	        //logger.info(lineFromFile);
	      }
	    }catch(Exception e){	      
	      throw new FileException("" + e.getMessage());
	    }
	}
		
	
	
	
	
/*	public static void main(String args[]){
		List<String> lines = Arrays.asList("The first line", "The second line");
		FileWriter write = new FileWriter();
		try {
			write.create("test");
			write.write("This is test");
			write.writeToNewLine("First");
			write.writeToNewLine("Second");
			write.write("End of test");
			write.close();
			write.read();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
        */
}
