import threading
from src.consumers.kafka_consumer import load_event_data_from_kafka
from src.services.cosmos_service import load_cv_data_from_cosmos
from src.services.rest_api_service import load_item_data_from_rest
from src.core.coordinate_matching import extract_coordinates_from_excel, get_rfx_rfy_list
from src.utils.data_cleaning import filter_and_clean_item_data, filter_by_coordinate_proximity

def main():
    load_result = {}

    def load_kafka():
        print("Loading Kafka data...")
        load_result["kafka"] = load_event_data_from_kafka()
        print("Kafka data loaded.")

    def load_cv():
        print("Loading CV data from Cosmos DB...")
        load_result["cv"] = load_cv_data_from_cosmos()
        print("CV data loaded.")

    t1 = threading.Thread(target=load_kafka)
    t2 = threading.Thread(target=load_cv)
    t1.start()
    t2.start()
    t1.join()
    t2.join()

    unknown_items = [item for item in load_result["kafka"] if item.get("Item_type") == "unknown"]
    cvdata_df = load_result["cv"]

    all_matched_rows = []
    all_matched_coords = []
    global_id_coord_map = {}

    batch_size = 5
    for i in range(0, len(unknown_items), batch_size):
        batch = unknown_items[i:i + batch_size]
        matched_rows, matched_coords, coord_map = extract_coordinates_from_excel(cvdata_df, batch)
        all_matched_rows.extend(matched_rows)
        all_matched_coords.extend(matched_coords)
        for gid, coords in coord_map.items():
            if gid not in global_id_coord_map:
                global_id_coord_map[gid] = []
            global_id_coord_map[gid].extend(coords)

    rfx_rfy_list = []
    for gid in global_id_coord_map:
        rfx_rfy_list.extend(get_rfx_rfy_list(global_id_coord_map, gid))

    print("Loading item data from REST API...")
    item_df = load_item_data_from_rest()
    filtered_df = filter_and_clean_item_data(item_df)
    matching_rows = filter_by_coordinate_proximity(filtered_df, rfx_rfy_list)

    print("\nFiltered Moving Item Data:")
    print(matching_rows)


if __name__ == "__main__":
    main()
