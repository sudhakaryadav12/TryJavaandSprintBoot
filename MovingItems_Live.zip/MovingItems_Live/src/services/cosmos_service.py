from pymongo import MongoClient
import pandas as pd
from src.config.settings import COSMOS_DB_CONN_STRING, COSMOS_DB_NAME, COSMOS_COLLECTION

def load_cv_data_from_cosmos():
    client = MongoClient(COSMOS_DB_CONN_STRING)
    db = client[COSMOS_DB_NAME]
    collection = db[COSMOS_COLLECTION]
    data = list(collection.find())
    return pd.DataFrame(data)