import requests
import pandas as pd
from src.config.settings import REST_API_URL

def load_item_data_from_rest():
    page = 1
    all_data = []
    while True:
        response = requests.get(REST_API_URL.format(page))
        if response.status_code != 200:
            break
        page_data = response.json()
        if not page_data:
            break
        all_data.extend(page_data)
        page += 1
    return pd.DataFrame(all_data)
