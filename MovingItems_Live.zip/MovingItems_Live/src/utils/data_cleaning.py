import pandas as pd
import numpy as np

def filter_and_clean_item_data(df):
    df = df[~df["events"].isin(["Departure", "Exit"])]
    df = df[df["regionName"].str.contains("apparel pad", case=False, na=False)]
    df["x"] = pd.to_numeric(df["x"], errors='coerce')
    df["y"] = pd.to_numeric(df["y"], errors='coerce')
    df = df.dropna(subset=["x", "y"])
    return df


def filter_by_coordinate_proximity(df, rfx_rfy_list, tolerance=50):
    rfx_array = np.array([pt['rfx'] for pt in rfx_rfy_list])
    rfy_array = np.array([pt['rfy'] for pt in rfx_rfy_list])

    def is_near(row):
        distance = np.sqrt((rfx_array - row["x"]) ** 2 + (rfy_array - row["y"]) ** 2)
        return np.any(distance <= tolerance)

    return df[df.apply(is_near, axis=1)]
