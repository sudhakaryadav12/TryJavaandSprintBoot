import ast

def extract_matching_coordinates(cv_match_df, unknown_items):
    matched_rows = []
    matched_coords = []
    coord_map = {}
    for item in unknown_items:
        sng_did = item.get("sng_did")
        global_id = item.get("global_id")
        person_event_time = item.get("person_event_time")
        filtered = cv_match_df[
            (cv_match_df["sng_did"] == sng_did) & (cv_match_df["global_id"] == global_id)
        ]
        for _, row in filtered.iterrows():
            matched_rows.append(row.to_dict())
            coords_raw = row.get("timestamp_coordinates")
            if not coords_raw or not str(coords_raw).strip().startswith("["):
                continue
            try:
                parsed_coords = ast.literal_eval(coords_raw)
                if not isinstance(parsed_coords, list):
                    continue
                valid_coords = [coord for coord in parsed_coords if isinstance(coord, (list, tuple)) and len(coord) == 3]
                for coord in valid_coords:
                    timevalue, x, y = coord
                    if timevalue == person_event_time:
                        try:
                            x = int(float(x))
                            y = int(float(y))
                            rfx = x
                            rfy = 4960 - y
                            matched_coords.append({"x": x, "y": y})
                            if global_id not in coord_map:
                                coord_map[global_id] = []
                            coord_map[global_id].append({
                                "person_event_time": person_event_time,
                                "x": x,
                                "y": y,
                                "rfx": rfx,
                                "rfy": rfy
                            })
                        except Exception:
                            continue
            except (SyntaxError, ValueError):
                continue
    return matched_rows, matched_coords, coord_map


def get_rfx_rfy_list(coord_map, global_id):
    return [{"rfx": entry["rfx"], "rfy": entry["rfy"]} for entry in coord_map.get(global_id, [])]
