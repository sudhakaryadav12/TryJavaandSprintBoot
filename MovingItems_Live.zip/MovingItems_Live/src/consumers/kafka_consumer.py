from kafka import KafkaConsumer
import json
from src.config.settings import KAFKA_BROKER, KAFKA_TOPIC

def load_event_data_from_kafka():
    consumer = KafkaConsumer(
        KAFKA_TOPIC,
        bootstrap_servers=[KAFKA_BROKER],
        auto_offset_reset='earliest',
        enable_auto_commit=True,
        value_deserializer=lambda x: json.loads(x.decode('utf-8'))
    )
    messages = []
    for message in consumer:
        messages.append(message.value)
        if len(messages) >= 100:
            break
    consumer.close()
    return messages