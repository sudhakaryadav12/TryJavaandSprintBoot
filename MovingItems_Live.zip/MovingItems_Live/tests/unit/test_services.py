import pytest
from unittest import mock
from src.services import cosmos_service, rest_api_service
from src.consumers import kafka_consumer

# ---------- services/cosmos_service.py ----------

@mock.patch("src.services.cosmos_service.CosmosClient")
def test_load_cv_data_from_cosmos_returns_data(mock_client):
    container_mock = mock.Mock()
    container_mock.query_items.return_value = [{"rfx": 1, "rfy": 2}]
    mock_client.return_value.get_database_client.return_value.get_container_client.return_value = container_mock
    
    result = cosmos_service.load_cv_data_from_cosmos()
    assert isinstance(result, list)

# ---------- services/rest_api_service.py ----------

@mock.patch("src.services.rest_api_service.requests.get")
def test_load_item_data_from_rest_success(mock_get):
    mock_get.return_value.status_code = 200
    mock_get.return_value.json.return_value = [{"item_id": "1", "rfx": 10, "rfy": 10}]
    
    data = rest_api_service.load_item_data_from_rest()
    assert isinstance(data, list)
    assert data[0]["item_id"] == "1"

@mock.patch("src.services.rest_api_service.requests.get")
def test_load_item_data_from_rest_failure(mock_get):
    mock_get.return_value.status_code = 500
    with pytest.raises(Exception):
        rest_api_service.load_item_data_from_rest()

# ---------- consumers/kafka_consumer.py ----------

@mock.patch("src.consumers.kafka_consumer.KafkaConsumer")
def test_load_event_data_from_kafka_returns_data(mock_consumer_class):
    mock_consumer = mock.Mock()
    mock_consumer.__iter__ = lambda self: iter([
        mock.Mock(value=b'{\"item_id\": \"1\", \"rfx\": 1, \"rfy\": 1}')
    ])
    mock_consumer_class.return_value = mock_consumer
    
    events = kafka_consumer.load_event_data_from_kafka()
    assert isinstance(events, list)
    assert events[0]["item_id"] == "1"
