import pytest
from src.utils.data_cleaning import is_near, filter_by_coordinate_proximity, filter_and_clean_item_data
from src.core.coordinate_matching import extract_matching_coordinates, get_rfx_rfy_list

# ---------- utils/data_cleaning.py ----------

def test_is_near_within_threshold():
    assert is_near(0, 0, 3, 4, threshold=5.0) is True  # distance is 5

def test_is_near_outside_threshold():
    assert is_near(0, 0, 6, 8, threshold=5.0) is False  # distance is 10

def test_filter_by_coordinate_proximity_returns_matches():
    items = [{"rfx": 10, "rfy": 10, "item_id": "123"}]
    result = filter_by_coordinate_proximity(items, 12, 12)
    assert len(result) == 1

def test_filter_by_coordinate_proximity_returns_empty():
    items = [{"rfx": 100, "rfy": 100, "item_id": "123"}]
    result = filter_by_coordinate_proximity(items, 0, 0)
    assert result == []

def test_filter_and_clean_item_data_removes_invalid_items():
    raw_data = [{"item_id": "123", "rfx": 1, "rfy": 1}, {"invalid": True}]
    cleaned = filter_and_clean_item_data(raw_data)
    assert all("item_id" in item for item in cleaned)

# ---------- core/coordinate_matching.py ----------

def test_extract_matching_coordinates_finds_matches():
    items = [{"item_id": "123", "rfx": 10, "rfy": 10}]
    refs = [{"rfx": 11, "rfy": 11}]
    matches = extract_matching_coordinates(items, refs)
    assert len(matches) == 1

def test_extract_matching_coordinates_finds_none():
    items = [{"item_id": "123", "rfx": 50, "rfy": 50}]
    refs = [{"rfx": 0, "rfy": 0}]
    matches = extract_matching_coordinates(items, refs)
    assert matches == []

def test_get_rfx_rfy_list_extracts_coordinates():
    data = [{"rfx": 1, "rfy": 2}, {"rfx": 3, "rfy": 4}]
    result = get_rfx_rfy_list(data)
    assert result == [(1, 2), (3, 4)]

def test_get_rfx_rfy_list_handles_empty():
    assert get_rfx_rfy_list([]) == []
