import pytest
import sys
from unittest import mock
from MovingItems_Live import app

# ---------- app.py ----------

@mock.patch("MovingItems_Live.app.load_kafka")
def test_main_calls_load_kafka(mock_load_kafka):
    sys.argv = ["app.py", "kafka"]
    app.main()
    mock_load_kafka.assert_called_once()

@mock.patch("MovingItems_Live.app.load_cv")
def test_main_calls_load_cv(mock_load_cv):
    sys.argv = ["app.py", "cv"]
    app.main()
    mock_load_cv.assert_called_once()

def test_main_no_arguments_prints_usage(capfd):
    sys.argv = ["app.py"]
    app.main()
    out, err = capfd.readouterr()
    assert "Usage:" in out or "kafka" in out.lower()
