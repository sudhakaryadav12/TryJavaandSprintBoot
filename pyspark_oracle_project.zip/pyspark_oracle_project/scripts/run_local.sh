
#!/usr/bin/env bash
set -euo pipefail

# Example local run using the PySpark wheel and --ojdbc flag
python src/main.py       --input data/transactions.csv       --jdbc-url "jdbc:oracle:thin:@//HOSTNAME:1521/SERVICE"       --user "YOUR_USER"       --password "YOUR_PASSWORD"       --table "DEMO_TRANSACTIONS"       --mode "append"       --filter-col "status" --filter-op "eq" --filter-val "APPROVED"       --search-col "description" --search-text "fuel"       --ojdbc /path/to/ojdbc8.jar       --show 10
