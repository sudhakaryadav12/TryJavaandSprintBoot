
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F
from pyspark.sql import types as T

def build_spark(app_name: str = "CSV_to_Oracle", ojdbc_path: str | None = None) -> SparkSession:
    builder = SparkSession.builder.appName(app_name)
    if ojdbc_path:
        # Ensure the Oracle JDBC driver is available on the classpath
        builder = builder.config("spark.jars", ojdbc_path)
    spark = builder.getOrCreate()
    return spark

def read_csv(spark: SparkSession, path: str, header: bool = True, infer_schema: bool = True) -> DataFrame:
    return (
        spark.read.option("header", str(header).lower())
                  .option("inferSchema", str(infer_schema).lower())
                  .csv(path)
    )

def apply_filters(
    df: DataFrame,
    filter_col: str | None = None,
    filter_op: str | None = None,
    filter_val: str | None = None,
    search_col: str | None = None,
    search_text: str | None = None,
    range_col: str | None = None,
    min_val: float | None = None,
    max_val: float | None = None,
) -> DataFrame:
    out = df

    # Typed filter when possible
    if filter_col and filter_op and filter_val is not None:
        col = F.col(filter_col)
        # Try to cast numeric if column is numeric
        dtype = dict(out.dtypes).get(filter_col)
        val = filter_val
        if dtype in ("int", "bigint", "double", "float", "long", "decimal", "short"):
            try:
                val = float(filter_val)
            except Exception:
                pass

        ops = {
            "eq": col == val,
            "ne": col != val,
            "gt": col > val,
            "gte": col >= val,
            "lt": col < val,
            "lte": col <= val,
        }
        expr = ops.get(filter_op.lower())
        if expr is None:
            raise ValueError(f"Unsupported filter-op: {filter_op}. Use one of {list(ops.keys())}")
        out = out.filter(expr)

    if search_col and search_text:
        out = out.filter(F.lower(F.col(search_col)).contains(search_text.lower()))

    if range_col and (min_val is not None or max_val is not None):
        col = F.col(range_col).cast("double")
        if min_val is not None:
            out = out.filter(col >= float(min_val))
        if max_val is not None:
            out = out.filter(col <= float(max_val))

    return out

def write_to_oracle(
    df: DataFrame,
    jdbc_url: str,
    table: str,
    user: str,
    password: str,
    mode: str = "append",
) -> None:
    (
        df.write
          .format("jdbc")
          .option("url", jdbc_url)
          .option("dbtable", table)
          .option("user", user)
          .option("password", password)
          .option("driver", "oracle.jdbc.OracleDriver")
          .mode(mode)
          .save()
    )
