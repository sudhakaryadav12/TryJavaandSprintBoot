
import argparse, sys, yaml
from spark_job import build_spark, read_csv, apply_filters, write_to_oracle

def load_config(path: str | None):
    if not path:
        return {}
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}

def parse_args():
    p = argparse.ArgumentParser(description="CSV → Oracle via PySpark")
    p.add_argument("--config", default="config/app_config.yaml", help="YAML config with defaults")
    p.add_argument("--input", required=False, default="data/transactions.csv", help="Path to input CSV")
    p.add_argument("--ojdbc", required=False, help="Path to ojdbc8.jar (Oracle JDBC driver)")

    # Processing options
    p.add_argument("--filter-col", help="Column for equality/inequality/range filter")
    p.add_argument("--filter-op", help="eq|ne|gt|gte|lt|lte")
    p.add_argument("--filter-val", help="Value for filter-op")
    p.add_argument("--search-col", help="Column to apply case-insensitive contains")
    p.add_argument("--search-text", help="Text to search for")
    p.add_argument("--range-col", help="Numeric column for min/max filter (cast to double)")
    p.add_argument("--min-amount", type=float, help="Minimum value for range-col")
    p.add_argument("--max-amount", type=float, help="Maximum value for range-col")

    # JDBC / target
    p.add_argument("--jdbc-url", help="Oracle JDBC URL, e.g. jdbc:oracle:thin:@//host:1521/service")
    p.add_argument("--user", help="DB username")
    p.add_argument("--password", help="DB password")
    p.add_argument("--table", help="Target table name")
    p.add_argument("--mode", default="append", help="Save mode: append|overwrite|error|ignore")

    p.add_argument("--print-schema", action="store_true", help="Print inferred schema and exit")
    p.add_argument("--show", type=int, default=0, help="Show top N rows before write")
    return p.parse_args()

def main():
    args = parse_args()

    # Merge config defaults
    cfg = load_config(args.config)
    jdbc_url = args.jdbc_url or cfg.get("jdbc_url")
    user = args.user or cfg.get("user")
    password = args.password or cfg.get("password")
    table = args.table or cfg.get("table")
    mode = args.mode or cfg.get("mode", "append")

    if not all([jdbc_url, user, password, table]):
        print("ERROR: Provide JDBC credentials via CLI or config/app_config.yaml", file=sys.stderr)
        sys.exit(2)

    spark = build_spark(ojdbc_path=args.ojdbc)
    df = read_csv(spark, args.input)

    if args.print_schema:
        df.printSchema()

    # Processing
    df2 = apply_filters(
        df,
        filter_col=args.filter_col,
        filter_op=args.filter_op,
        filter_val=args.filter_val,
        search_col=args.search_col,
        search_text=args.search_text,
        range_col=args.range_col,
        min_val=args.min_amount,
        max_val=args.max_amount,
    )

    if args.show:
        df2.show(args.show, truncate=False)

    # Write to Oracle
    write_to_oracle(df2, jdbc_url=jdbc_url, table=table, user=user, password=password, mode=mode)

    print("✅ Job complete.")
    spark.stop()

if __name__ == "__main__":
    main()
