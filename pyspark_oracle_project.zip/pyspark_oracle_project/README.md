
# PySpark CSV → Oracle JDBC Demo

A minimal PySpark project that:
1) reads a CSV,
2) performs simple processing (filtering + "search/contains"),
3) writes the result into an Oracle table via JDBC.

---

## Project layout
```text
pyspark_oracle_project/
├── README.md
├── requirements.txt
├── config/
│   └── app_config.yaml
├── data/
│   └── transactions.csv
├── scripts/
│   ├── run_local.sh
│   └── submit_spark.sh
└── src/
    ├── main.py
    └── spark_job.py
```

## Prerequisites
- Python 3.10+
- Java 8+ (or 11)
- Apache Spark 3.x (or use `pip install pyspark`)
- **Oracle JDBC driver** (e.g. `ojdbc8.jar`) — download from Oracle and accept the license.

> This repo does **not** bundle `ojdbc8.jar`. Put it anywhere on your machine and pass the path via `--ojdbc` or set `SPARK_CLASSPATH`.

## Quickstart (local with `pyspark` wheel)
```bash
# 1) Create a venv (optional)
python -m venv .venv && source .venv/bin/activate  # Windows: .venv\Scripts\activate

# 2) Install deps
pip install -r requirements.txt

# 3) Run
python src/main.py       --input data/transactions.csv       --jdbc-url "jdbc:oracle:thin:@//HOSTNAME:1521/SERVICE"       --user "YOUR_USER"       --password "YOUR_PASSWORD"       --table "DEMO_TRANSACTIONS"       --mode "overwrite"       --filter-col "status" --filter-op "eq" --filter-val "APPROVED"       --search-col "description" --search-text "fuel"       --ojdbc /path/to/ojdbc8.jar
```

If you prefer `spark-submit`:
```bash
spark-submit       --jars /path/to/ojdbc8.jar       --py-files src/spark_job.py       src/main.py       --input data/transactions.csv       --jdbc-url "jdbc:oracle:thin:@//HOSTNAME:1521/SERVICE"       --user "YOUR_USER"       --password "YOUR_PASSWORD"       --table "DEMO_TRANSACTIONS"
```

## What the job does
- Reads CSV with headers and infers schema.
- Optional filtering: `--filter-col`, `--filter-op` (`eq`, `ne`, `gt`, `gte`, `lt`, `lte`) and `--filter-val`.
- Optional search: `--search-col` + `--search-text` (case-insensitive contains).
- Optional numeric range: `--min-amount` / `--max-amount` on a numeric column.
- Writes to Oracle using `df.write.format("jdbc")` with `mode` (`append`/`overwrite`/`error`/`ignore`).

## Create target table in Oracle (example)
```sql
CREATE TABLE DEMO_TRANSACTIONS (
  txn_id        NUMBER,
  customer_id   NUMBER,
  amount        NUMBER(12,2),
  currency      VARCHAR2(10),
  status        VARCHAR2(32),
  description   VARCHAR2(400),
  txn_ts        TIMESTAMP
);
```
Spark can also create the table automatically on first write with `overwrite`, depending on permissions.

## Configuration (optional)
You can also put defaults in `config/app_config.yaml` and omit them from CLI:
```yaml
jdbc_url: "jdbc:oracle:thin:@//HOST:1521/SERVICE"
user: "scott"
password: "tiger"
table: "DEMO_TRANSACTIONS"
mode: "append"
```

## Troubleshooting
- **Class not found `oracle.jdbc.OracleDriver`**: Ensure `ojdbc8.jar` is on the classpath, either via `--ojdbc`, `--jars`, or `SPARK_CLASSPATH`.
- **ORA-01017**: Bad credentials. Double-check `--user/--password`.
- **ORA-00942**: Table or view does not exist. Create it or use `--mode overwrite` with sufficient permissions.
- **Datatype mismatch**: Check inferred schema (`--print-schema`) and Oracle table column types.
- **Firewall / networking**: Verify you can reach the DB host/port from the Spark driver & executors.
```

## License
MIT (sample code). Oracle JDBC driver is subject to Oracle's license.
