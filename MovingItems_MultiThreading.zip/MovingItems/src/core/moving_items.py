import pandas as pd
import numpy as np
import ast
import threading

from src.consumers.kafka_event_loader import load_event_data
from src.utils.data_loader import load_cv_data

def extract_coordinates_from_excel(cv_excel_df, unknown_items):
    matched_rows = []
    matched_coords = []
    coord_map = {}
    for item in unknown_items:
        sng_did = item.get("sng_did")
        global_id = item.get("global_id")
        person_event_time = item.get("person_event_time")
        filtered = cv_excel_df[
            (cv_excel_df["sng_did"] == sng_did) & (cv_excel_df["global_id"] == global_id)
        ]
        for _, row in filtered.iterrows():
            matched_rows.append(row.to_dict())
            coords_raw = row.get("timestamp_coordinates")
            if not coords_raw or not coords_raw.strip().startswith("[") or not coords_raw.strip().endswith("]"):
                continue
            try:
                parsed_coords = ast.literal_eval(coords_raw)
                if not isinstance(parsed_coords, list):
                    continue
                valid_coords = [
                    coord for coord in parsed_coords
                    if isinstance(coord, (list, tuple)) and len(coord) == 3
                ]
                for coord in valid_coords:
                    timevalue, x, y = coord
                    if timevalue == person_event_time:
                        try:
                            x = int(float(x))
                            y = int(float(y))
                            rfx =  x
                            rfy = 4960 - y
                            matched_coords.append({"x": x, "y": y})
                            if global_id not in coord_map:
                                coord_map[global_id] = []
                            coord_map[global_id].append({
                                "person_event_time": person_event_time,
                                "x": x,
                                "y": y,
                                "rfx": rfx,
                                "rfy": rfy
                            })
                        except Exception:
                            continue
            except (SyntaxError, ValueError):
                continue
    return matched_rows, matched_coords, coord_map

def get_rfx_rfy_list(coord_map, global_id):
    return [{"rfx": entry["rfx"], "rfy": entry["rfy"]}
            for entry in coord_map.get(global_id, [])]

def filter_and_clean_item_data(df):
    df = df[~df["events"].isin(["Departure", "Exit"])]
    df = df[df["regionName"].str.contains("apparel pad", case=False, na=False)]
    df["x"] = pd.to_numeric(df["x"], errors='coerce')
    df["y"] = pd.to_numeric(df["y"], errors='coerce')
    df = df.dropna(subset=["x", "y"])
    return df

def filter_by_coordinate_proximity(df, rfx_rfy_list, tolerance=50):
    rfx_array = np.array([point['rfx'] for point in rfx_rfy_list])
    rfy_array = np.array([point['rfy'] for point in rfx_rfy_list])
    def is_near(row):
        distance = np.sqrt((rfx_array-row["x"])**2+(rfy_array-row["y"])**2)
        return np.any(distance <= tolerance)
    return df[df.apply(is_near, axis=1)]

def main():
    # File paths
    kafkatopicjson_file = "data/kafkatopicdata.json"
    cvdata_file = "data/CVdata22.xlsx"
    itemcoreserver_file = "data/item_data_01.csv"

    # Shared variables
    load_result = {}

    def load_kafka():
        print("Loading Kafka JSON...")
        load_result["kafka"] = load_event_data(kafkatopicjson_file)
        print("Kafka JSON loaded.")

    def load_cv():
        print("Loading CV Excel...")
        load_result["cv"] = load_cv_data(cvdata_file)
        print("CV Excel loaded.")

    # Load Kafka and CV in parallel
    t1 = threading.Thread(target=load_kafka)
    t2 = threading.Thread(target=load_cv)
    t1.start()
    t2.start()
    t1.join()
    t2.join()

    unknown_kafka_event_json = load_result["kafka"]
    cvdata_df = load_result["cv"]

    unknown_items = [item for item in unknown_kafka_event_json if item.get("Item_type") == "unknown"]

    all_matched_rows = []
    all_matched_coords = []
    global_id_coord_map = {}

    batch_size = 5
    for i in range(0, len(unknown_items), batch_size):
        batch = unknown_items[i:i + batch_size]
        matched_rows, matched_coords, coord_map = extract_coordinates_from_excel(cvdata_df, batch)
        all_matched_rows.extend(matched_rows)
        all_matched_coords.extend(matched_coords)
        for gid, coords in coord_map.items():
            if gid not in global_id_coord_map:
                global_id_coord_map[gid] = []
            global_id_coord_map[gid].extend(coords)

    rfx_rfy_list = []
    for gid in global_id_coord_map:
        rfx_rfy_list.extend(get_rfx_rfy_list(global_id_coord_map, gid))

    print("Loading item CSV in chunks...")
    chunksize = 10000
    matching_rows_accumulator = []

    for chunk in pd.read_csv(itemcoreserver_file, chunksize=chunksize):
        filtered_chunk = filter_and_clean_item_data(chunk)
        matching_chunk = filter_by_coordinate_proximity(filtered_chunk, rfx_rfy_list)
        if not matching_chunk.empty:
            matching_rows_accumulator.append(matching_chunk)

    final_matching_rows = pd.concat(matching_rows_accumulator, ignore_index=True)

    print("\nFiltered Moving Item Data:")
    print(final_matching_rows.head(10))  # Top 10 for brevity

if __name__ == "__main__":
    main()
