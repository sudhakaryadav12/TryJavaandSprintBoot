/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.oru.modelExtract;

import com.oru.dao.DBConnection;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author TALATIS
 */
public class StepTransformerAttributesThread extends Thread  {
    
    HashMap<Integer, Asset> assetMaster;
    String assetToQuery;
    
    private final static Logger logger = LoggerFactory.getLogger(StepTransformerAttributesThread.class);

    StepTransformerAttributesThread(HashMap<Integer, Asset> assetMaster,String assetToQuery) {
        this.assetMaster = assetMaster;   
        this.assetToQuery = assetToQuery;
    }
    
    
    
    
        public void run() {

        //logger.info("Thread starting");
        try (Connection con = DBConnection.getConnectionToPG();
                Statement connectionGeomStmt = con.createStatement();) {


            
            String newPointQuery = "select geom.fid,geom.featuretypeid,def.featuretypename,geom.attributes,GeometryType(geom.geom) geomType,\n" +
                        "geom.rotation,ST_X(geom) xValue, ST_Y(geom) yValue, StepTransformer.circuit,StepTransformer.seg,\n" +
                        "StepTransformer.subseg,StepTransformer.gridx,StepTransformer.gridy,\n" +
                        "StepTransformer.tcn_1,StepTransformer.tcn_2,StepTransformer.tcn_3,\n" +
                        "StepTransformer.bank1,StepTransformer.bank2,StepTransformer.bank3,\n" +                    
                        "StepTransformer.xfmr2,StepTransformer.xfmr3,StepTransformer.tax,\n" +                    
                        "StepTransformer.street,StepTransformer.wms,StepTransformer.involt,StepTransformer.outvolt,\n" +                                            
                        "StepTransformer.neutral,StepTransformer.kva1,StepTransformer.kva2,StepTransformer.kva3,\n" +                                            
                        "StepTransformer.code,StepTransformer.div,StepTransformer.status,StepTransformer.sotagged,StepTransformer.type,StepTransformer.contype,StepTransformer.mainline\n" +                                            
                        "from \n" +
                        "ed.geom geom, nrgcore.nrgfeaturetypedef def, asset_ed.ed_step_xfmr StepTransformer\n" +
                        "where geom.fid = StepTransformer.fid \n" +
                        "and geom.featuretypeid = def.featuretypeid \n" + 
                        "and StepTransformer.fid in (" + assetToQuery + ") ";
            
            //####logger.info(connectionGeomQuery);
            ResultSet rs = connectionGeomStmt.executeQuery(newPointQuery);
            
            while (rs.next()) {
                int fid = rs.getInt("fid");
                Asset asset = assetMaster.get(fid);

                if (asset != null) {

                    //asset.setCircuit(circuit);
                    asset.setNmsAttributes("fid", String.valueOf(fid));

                    int ftypeid = rs.getInt("featuretypeid");
                    asset.setNmsAttributes("featuretypeid", String.valueOf(ftypeid));

                    String featuretypename = rs.getString("featuretypename");
                    asset.setNmsAttributes("featuretypename", featuretypename);
                    asset.setAssetType(featuretypename);

                    String geomType = rs.getString("geomType");
                    asset.setNmsGeomAttributes("geomType", geomType);
                    asset.setGeomType(geomType);

                    String circuit = rs.getString("circuit");
                    if (circuit.equalsIgnoreCase("L100-00/00-34")) {
                          circuit = "L6-00/00-34";
                    }                    
                    asset.setCircuit(circuit);
                    
                    String attributes = rs.getString("attributes");
                    if (attributes != null) {
                        for (String retval : attributes.split("::")) {
                            String val[] = retval.split(":");
                            asset.setNmsAttributes(val[0], val[1]);
                        }
                    }

                    String segment = rs.getString("seg");
                    asset.setNmsAttributes("seg", segment);

                    String subSegment = rs.getString("subseg");
                    asset.setNmsAttributes("subSegment", subSegment);

                    int gridx = rs.getInt("gridx");
                    asset.setNmsAttributes("gridx", Integer.toString(gridx));

                    int gridy = rs.getInt("gridy");
                    asset.setNmsAttributes("gridy", Integer.toString(gridy));
                    
                    double rotation = rs.getFloat("rotation");
                    asset.setNmsGeomAttributes("rotation", String.valueOf(rotation));

                    double pointX = rs.getFloat("xValue");
                    double pointY = rs.getFloat("yValue");
                    String geometry = "(" + String.valueOf(pointX) + "," + String.valueOf(pointY) + ")";
                    asset.setNmsGeomAttributes("geometry", geometry);
                    
                    int bank1 = rs.getInt("bank1");
                    asset.setNmsAttributes("bank1", Integer.toString(bank1));

                    int bank2 = rs.getInt("bank2");
                    asset.setNmsAttributes("bank2", Integer.toString(bank2));

                    int bank3 = rs.getInt("bank3");
                    asset.setNmsAttributes("bank3", Integer.toString(bank3));

                    int tcn_1 = rs.getInt("tcn_1");
                    asset.setNmsAttributes("tcn_1", Integer.toString(tcn_1));

                    int tcn_2 = rs.getInt("tcn_2");
                    asset.setNmsAttributes("tcn_2", Integer.toString(tcn_2));

                    int tcn_3 = rs.getInt("tcn_3");
                    asset.setNmsAttributes("tcn_3", Integer.toString(tcn_3));

                    String xfmr2 = rs.getString("xfmr2");
                    asset.setNmsAttributes("xfmr2", xfmr2);

                    String xfmr3 = rs.getString("xfmr3");
                    asset.setNmsAttributes("xfmr3", xfmr3);
                    
                    String tax = rs.getString("tax");
                    asset.setNmsAttributes("tax", tax);
                    
                    String wms = rs.getString("wms");
                    asset.setNmsAttributes("wms", wms);

                    String street = rs.getString("street");
                    asset.setNmsAttributes("street", street);

                    int involt = rs.getInt("involt");
                    asset.setNmsAttributes("involt", Integer.toString(involt));

                    int outvolt = rs.getInt("outvolt");
                    asset.setNmsAttributes("outvolt", Integer.toString(outvolt));
                    
                    int neutral = rs.getInt("neutral");
                    asset.setNmsAttributes("neutral", Integer.toString(neutral));
                    
                    int kva1 = rs.getInt("kva1");
                    asset.setNmsAttributes("kva1", Integer.toString(kva1));

                    int kva2 = rs.getInt("kva2");
                    asset.setNmsAttributes("kva2", Integer.toString(kva2));

                    int kva3 = rs.getInt("kva3");
                    asset.setNmsAttributes("kva3", Integer.toString(kva3));
                    
                    String code = rs.getString("code");
                    asset.setNmsAttributes("code", code);
                    
                    int div = rs.getInt("div");
                    asset.setNmsAttributes("div", Integer.toString(div));

                    String status = rs.getString("status");
                    asset.setNmsAttributes("status", status);
                    
                    boolean sotagged = rs.getBoolean("sotagged");
                    asset.setNmsAttributes("sotagged", String.valueOf(sotagged));
                    
                    String type = rs.getString("type");
                    asset.setNmsAttributes("type", type);
                    
                    String contype = rs.getString("contype");
                    asset.setNmsAttributes("contype", contype);
                    
                    String mainline = rs.getString("mainline");
                    asset.setNmsAttributes("mainline", mainline);

                }

            }
            rs.close();
            //####logger.info("Thread finished processing");
        } catch (Exception e) {
            logger.error(e.getMessage());
        }

    }

}
