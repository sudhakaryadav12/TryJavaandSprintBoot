/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.oru.modelExtract;

import com.oru.dao.DBConnection;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author TALATIS
 */
public class PrimaryMeterAttributesThread extends Thread  {
    
    HashMap<Integer, Asset> assetMaster;
    String assetToQuery;
    
    private final static Logger logger = LoggerFactory.getLogger(PrimaryMeterAttributesThread.class);

    PrimaryMeterAttributesThread(HashMap<Integer, Asset> assetMaster,String assetToQuery) {
        this.assetMaster = assetMaster;        
        this.assetToQuery = assetToQuery;
    }
    
    
    
    
        public void run() {

        //logger.info("Thread starting");
        try (Connection con = DBConnection.getConnectionToPG();
                Statement connectionGeomStmt = con.createStatement();) {


            
            String newPointQuery = "select geom.fid,geom.featuretypeid,def.featuretypename,\n" +
"                    GeometryType(geom.geom) geomType,geom.rotation,ST_X(geom) xValue,\n" +
"                    ST_Y(geom) yValue, pm.gridx, pm.gridy, pm.circuit, pm.seg, pm.phase, pm.insttype, \n" +
"		             pm.wafid1, pm.wafid2, pm.premise,pm.fid1,pm.fid2,pm.subseg,pm.type,pm.mainline  \n" +
"                    from ed.geom geom, nrgcore.nrgfeaturetypedef def, asset_ed.ed_primarymeter pm\n" +
"                    where geom.featuretypeid = def.featuretypeid\n" +
"                    and pm.fid = geom.fid  \n" + 
"                    and pm.fid in (" + assetToQuery + ") ";
            //####logger.info(connectionGeomQuery);
            ResultSet rs = connectionGeomStmt.executeQuery(newPointQuery);
            
            while (rs.next()) {
                int fid = rs.getInt("fid");
                Asset asset = assetMaster.get(fid);

                if (asset != null) {

                    //asset.setCircuit(circuit);
                    asset.setNmsAttributes("fid", String.valueOf(fid));

                    int ftypeid = rs.getInt("featuretypeid");
                    asset.setNmsAttributes("featuretypeid", String.valueOf(ftypeid));

                    String featuretypename = rs.getString("featuretypename");
                    asset.setNmsAttributes("featuretypename", featuretypename);
                    asset.setAssetType(featuretypename);

                    String geomType = rs.getString("geomType");
                    asset.setNmsGeomAttributes("geomType", geomType);
                    asset.setGeomType(geomType);
                    
                    double rotation = rs.getFloat("rotation");
                    asset.setNmsGeomAttributes("rotation", String.valueOf(rotation));
                    
                    double pointX = rs.getFloat("xValue");
                    double pointY = rs.getFloat("yValue");
                    String geometry = "(" + String.valueOf(pointX) + "," + String.valueOf(pointY) + ")";
                    asset.setNmsGeomAttributes("geometry", geometry);

                    int gridx = rs.getInt("gridx");
                    asset.setNmsAttributes("gridx", Integer.toString(gridx));

                    int gridy = rs.getInt("gridy");
                    asset.setNmsAttributes("gridy", Integer.toString(gridy));

                    String circuit = rs.getString("circuit");
                    if (circuit.equalsIgnoreCase("L100-00/00-34")) {
                          circuit = "L6-00/00-34";
                    }                    
                    asset.setCircuit(circuit);
                    asset.setNmsAttributes("circuit", circuit);
                    
                    String segment = rs.getString("seg");
                    asset.setNmsAttributes("seg", segment);

                    int phase = rs.getInt("phase");
                    asset.setNmsAttributes("phase", Integer.toString(phase));
                    
                    String insttype = rs.getString("insttype");
                    asset.setNmsAttributes("insttype", insttype);                    
                    
                    int wafid1 = rs.getInt("wafid1");
                    asset.setNmsAttributes("wafid1", Integer.toString(wafid1));
                    
                    int wafid2 = rs.getInt("wafid2");
                    asset.setNmsAttributes("wafid2", Integer.toString(wafid2));
                    
                    long fid1 = rs.getLong("fid1");
                    asset.setNmsAttributes("fid1", Long.toString(fid1));
                    
                    long fid2 = rs.getLong("fid2");
                    asset.setNmsAttributes("fid2", Long.toString(fid2));
                    
                    String premise = rs.getString("premise");
                    asset.setNmsAttributes("premise", premise);                    

                    String mainline = rs.getString("mainline");
                    asset.setNmsAttributes("mainline", mainline);                    

                    String subseg = rs.getString("subseg");
                    asset.setNmsAttributes("subseg", subseg); 

                    String type = rs.getString("type");
                    asset.setNmsAttributes("type", type);                     
                }

            }
            rs.close();
            //####logger.info("Thread finished processing");
        } catch (Exception e) {
            logger.error(e.getMessage());
        }

    }

}
