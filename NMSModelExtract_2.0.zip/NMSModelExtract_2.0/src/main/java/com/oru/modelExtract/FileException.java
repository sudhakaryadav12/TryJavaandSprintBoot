package com.oru.modelExtract;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;


public class FileException extends Exception{

	
    
    
        /**
	 * @param exceptionMessage
	 */
	public FileException(String exceptionMessage) {
		super();
		this.exceptionMessage = exceptionMessage;
	}
	
	public FileException(Exception e) {
		super();
		ByteArrayOutputStream os = new ByteArrayOutputStream ();
		e.printStackTrace(new PrintStream (os));
		this.exceptionMessage = new String(os.toByteArray ());
	}

	private static final long serialVersionUID = 1L;	
	private String exceptionMessage;

	public String getExceptionMessage() {
		return exceptionMessage;
	}

	public void setExceptionMessage(String exceptionMessage) {
		this.exceptionMessage = exceptionMessage;
	}

}
