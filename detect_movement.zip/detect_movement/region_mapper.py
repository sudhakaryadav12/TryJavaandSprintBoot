class RegionMapper:
    def find_region(self, x_rf, y_rf):
        return f"region-{int(x_rf)%5}-{int(y_rf)%5}"

    def get_items_by_region(self, x_rf, y_rf):
        return [
            {"upc": "2903858848", "x_rf": x_rf, "y_rf": y_rf, "ts": datetime.now().timestamp()}
        ]
