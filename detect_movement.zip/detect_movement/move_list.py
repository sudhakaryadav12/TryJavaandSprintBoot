class MoveList:
    def __init__(self):
        self.moved = []

    def add(self, item):
        self.moved.append(item)
        print(f"✅ MoveList updated: {item}")
