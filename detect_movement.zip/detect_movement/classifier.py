class Classifier:
    def __init__(self, threshold=5.0):
        self.threshold = threshold

    def classify(self, data_group):
        if len(data_group) == 1:
            return "Stationary"

        timestamps = [d["rf"]["ts"] for d in data_group]
        time_gap = max(timestamps) - min(timestamps)

        cv_coords = [d["cv"] for d in data_group if d.get("cv")]
        rf_coords = [d["rf"] for d in data_group]

        avg_rf = self._average_coords(rf_coords)
        avg_cv = self._average_coords(cv_coords or rf_coords)

        distance = self._euclidean_distance(avg_rf, avg_cv)

        if time_gap > 2 and distance > self.threshold:
            return "Probably Moving"
        elif time_gap > 2:
            return "Fast Move"
        else:
            return "Movement Not Confirmed"

    def _average_coords(self, coords):
        x = sum(p["x"] for p in coords) / len(coords)
        y = sum(p["y"] for p in coords) / len(coords)
        return {"x": x, "y": y}

    def _euclidean_distance(self, a, b):
        return ((a["x"] - b["x"])**2 + (a["y"] - b["y"])**2) ** 0.5
