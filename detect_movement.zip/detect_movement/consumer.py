from kafka import KafkaConsumer
import json

class EventConsumer:
    def __init__(self, topic, servers):
        self.consumer = KafkaConsumer(
            topic,
            bootstrap_servers=servers,
            value_deserializer=lambda x: json.loads(x.decode("utf-8"))
        )

    def get_events(self):
        for message in self.consumer:
            event = message.value
            if event.get("item_type") == "unknown":
                yield event
