from consumer import EventConsumer
from transformer import Transformer
from region_mapper import RegionMapper
from aggregator import Aggregator
from classifier import Classifier
from move_list import MoveList

def main():
    consumer = EventConsumer(topic="isee-events", servers=["localhost:9092"])
    transformer = Transformer()
    region_mapper = RegionMapper()
    aggregator = Aggregator()
    classifier = Classifier()
    move_list = MoveList()

    for event in consumer.get_events():
        print(f"🔍 Processing unknown item event: {event}")

        x_cv, y_cv = 100, 200  # Simulated CV detection
        x_rf, y_rf = transformer.convert_cv_to_rf(x_cv, y_cv)

        region = region_mapper.find_region(x_rf, y_rf)
        region_items = region_mapper.get_items_by_region(x_rf, y_rf)

        for item in region_items:
            upc = item["upc"]
            rf_data = {"x": item["x_rf"], "y": item["y_rf"], "ts": item["ts"]}
            cv_data = {"x": x_cv, "y": y_cv}

            group = aggregator.aggregate(upc, rf_data, cv_data)
            status = classifier.classify(group)

            print(f"📦 Item {upc} classified as: {status}")

            if status in ["Probably Moving", "Fast Move"]:
                move_list.add({"upc": upc, "status": status, "region": region})

if __name__ == "__main__":
    main()
