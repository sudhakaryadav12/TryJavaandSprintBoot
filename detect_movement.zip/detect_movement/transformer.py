class Transformer:
    def convert_cv_to_rf(self, x_cv, y_cv):
        x_rf = 4094 - x_cv
        y_rf = 4094 - y_cv
        return x_rf, y_rf

