from collections import defaultdict

class Aggregator:
    def __init__(self):
        self.data = defaultdict(list)

    def aggregate(self, upc, rf_data, cv_data):
        self.data[upc].append({"rf": rf_data, "cv": cv_data})
        return self.data[upc]
